public interface Desconto {
    public double novoSalario(Pessoa pessoa);
}
